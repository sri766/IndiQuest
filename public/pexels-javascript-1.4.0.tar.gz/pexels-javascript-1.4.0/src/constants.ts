export const photoBaseUrl = "https://api.pexels.com/v1/";
export const videoBaseUrl = "https://api.pexels.com/videos/";
export const collectionBaseUrl = "https://api.pexels.com/v1/collections/";
